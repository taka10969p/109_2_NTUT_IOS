//
//  GameViewModel.swift
//  cardgame
//
//  Created by p on 2021/5/17.
//

import SwiftUI

class GameViewModel: ObservableObject {
@Published var playerCard: Card?
@Published var computerCard: Card?
@Published var result: GameResult?
var cards: [Card] = {
var cards = [Card]()

for rank in Card.Rank.allCases {
let card = Card( rank: rank)
cards.append(card)

}
return cards
}()
func play() {
cards.shuffle()
playerCard = cards[0]
computerCard = cards[1]
result = checkResult()
}
func checkResult() -> GameResult {

if (playerCard?.rank.rawValue=="剪刀✌🏻")
    {
        if(computerCard?.rank.rawValue=="石頭✊🏻")
        {
        return .lose
        }
        else if (computerCard?.rank.rawValue=="布✋🏻"){
        return .win
            }
}
    else if (playerCard?.rank.rawValue=="石頭✊🏻")
    {
        
        if(computerCard?.rank.rawValue=="剪刀✌🏻")
        {
        return .win
        }
        else if (computerCard?.rank.rawValue=="布✋🏻"){
        return .lose
            }
    }
    else if(playerCard?.rank.rawValue=="布✋🏻")
    {
        
        if(computerCard?.rank.rawValue=="剪刀✌🏻")
        {
        return .lose
        }
        else if (computerCard?.rank.rawValue=="石頭✊🏻"){
        return .win
            }
    }
    else{
    return .tie
    }
    return .tie
}
    
}

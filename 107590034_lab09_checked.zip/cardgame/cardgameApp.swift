//
//  cardgameApp.swift
//  cardgame
//
//  Created by p on 2021/5/17.
//

import SwiftUI

@main
struct cardgameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  ContentView.swift
//  cardgame
//
//  Created by p on 2021/5/17.
//

import SwiftUI


struct ContentView: View {
    @StateObject var gameViewModel = GameViewModel()
    @State var check=0
    var body: some View {
        VStack{
            Text("猜拳遊戲").font(.largeTitle)
        }
    VStack {
    HStack(spacing: 100.0) {
    HStack {
        Text("Player").font(.title)
        Text(gameViewModel.playerCard?.rank.rawValue ?? "石頭✊🏻").font(.title)
        }
    }
    HStack {
        Text("Computer").font(.title)

    Text(gameViewModel.computerCard?.rank
            .rawValue ?? "石頭").font(.title)
    
    }
        if(check==1){
    Text(gameViewModel.result == .win ? "Win 🥳" : "Lose 😥" )
    .font(.system(size: 100))
        }
        else
        {
            Text("請按按鈕")
            .font(.system(size: 100))
        }
    
    Button(action: {
        gameViewModel.play();check=1
    }, label: {
    Text("出拳")
    })
    }
    .font(.title2)
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

//
//  GameResult.swift
//  cardgame
//
//  Created by p on 2021/5/17.
//

import SwiftUI
enum GameResult {
case win
case lose
case tie
}

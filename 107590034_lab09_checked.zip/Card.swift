//
//  Card.swift
//  cardgame
//
//  Created by p on 2021/5/17.
//

import SwiftUI
struct Card {

let rank: Rank

enum Rank: String, CaseIterable {
case ace = "剪刀✌🏻"
case two = "石頭✊🏻"
case three = "布✋🏻"

}
}

//
//  ViewController.swift
//  Calculator
//
//  Created by Aaron Xue on 2019/9/24.
//  Copyright © 2019 Aaron Xue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    lazy var controller = Calculator()
    
    var pin = 0
    var init_o = 0
    var output=0.0
    var pin_check = 0
    var change = 0
    var opCodeRecord = 4
    var opCodeRecordArray = [String]()
    
    @IBOutlet weak var display: UILabel!
    @IBOutlet weak var processDisplay: UILabel!
    @IBOutlet weak var acButton: UIButton!
    
    var displayValue = "0" {
        didSet {
            display.text = "\(displayValue)"
        }
    }
    
    var processValue = "" {
        didSet {
            processDisplay.text = "\(processValue)"
            if(processValue == ""){
                acButton.setTitle("AC", for: .normal)
            }
        }
    }
    
    @IBOutlet var numButtons: [UIButton]!
    
    @IBAction func touchNum(_ sender: UIButton) {
        if(init_o==0)
        {
        if(opCodeRecord == -1){
            opCodeRecord = 4
            resetCal()
        }
        
        pin = 0
        
        if let txtNumber = numButtons.firstIndex(of: sender){
            displayProcess(value: String(txtNumber))
        }
        }
        else if(init_o==1)
        {
            resetCal()
            if(init_o==0)
            {
            if(opCodeRecord == -1){
                opCodeRecord = 4
                resetCal()
            }
            
            pin = 0
            
            if let txtNumber = numButtons.firstIndex(of: sender){
                displayProcess(value: String(txtNumber))
            }
            }
        }
    }
    
    
    @IBAction func touchPoit(_ sender: Any) {
        if(pin == 2) {
            return
        }
        if(pin_check == 0)
        {
            processValue = processValue + "."
            pin = 2
            pin_check = 1
            
        }
        
        
        
    }
    
    @IBOutlet var opeatorButton: [UIButton]!
    
    @IBAction func touchOperator(_ sender: UIButton) {
        
        if(opCodeRecord == -1){
            return
        }
       
        controller.reset = true
        controller.recordNumber = Double(Int(displayValue)!)
        if let opCode = opeatorButton.firstIndex(of: sender){
            opCodeRecord = opCode
            
            if(opCodeRecord != 4 && pin == 1){
                opCodeRecordArray.removeLast()
                processValue.removeLast()
            }
            pin = 1
            
            switch opCodeRecord {
            case 0:
                if(processValue == "") {
                    opCodeRecordArray.append("+")
                    processValue = "0+"
                    pin_check = 0
                }
                else
                {
                opCodeRecordArray.append("+")
                processValue = processValue + "+"
                pin_check = 0
                }
            case 1:
                if(processValue == "") {
                    opCodeRecordArray.append("-")
                    processValue = "0-"
                    pin_check = 0
                }
                else
                {
                opCodeRecordArray.append("-")
                processValue = processValue + "-"
                pin_check = 0
                }
            case 2:
                if(processValue == "") {
                    opCodeRecordArray.append("*")
                    processValue = "0*"
                    pin_check = 0
                }
                else
                {
                opCodeRecordArray.append("*")
                processValue = processValue + "*"
                pin_check = 0
                }
            case 3:
                if(processValue == "") {
                    opCodeRecordArray.append("/")
                    processValue = "0/"
                    pin_check = 0
                }
                else
                {
                opCodeRecordArray.append("/")
                processValue = processValue + "/"
                pin_check = 0
                }
            case 4:
                calculate()
                pin_check = 0
                init_o = 1
            case 5:
                output=Double(processValue) ?? 0
                processValue="+/-("+processValue+")"
                change=1
                calculate()
                
            
            default:
                return;
            }
        }
    }
    
    func calculate(){
        if(change==0){
        controller.cal(result: processValue, opRecord: opCodeRecordArray)
        displayResult(number: controller.numOfSum)
        opCodeRecord = -1
        }
        else if (change==1)
        {
            
           print(processValue)
            displayValue=String(-(output))
        
            
        }
    }
    
    
    func displayProcess(value: String){
        if(value == ""){
            processValue = ""
        }
        else {
            processValue = (processValue == "0") ? value : processValue + value
        }
        
    }
    
    func displayResult(number: Double){
        print(number)
        if(controller.reset == true){
            controller.reset = false
            displayValue = "0"
        }
        if(displayValue == "0"){
            if(floor(number) == number){
                displayValue = String(Int(number))
            } else {
                displayValue = String(number)
            }
        }else{
            displayValue += String(number)
        }
    }
    
    
    @IBAction func AC(_ sender: UIButton) {
        resetCal()
    }
    
    func resetCal(){
        clearStorages()
        clearDisplay()
    }
    
    func clearDisplay(){
        controller.reset = true
        displayProcess(value: "")
        displayResult(number: 0)
    }
    
    func clearStorages(){
        pin = 0
        pin_check = 0
        init_o = 0
        change = 0
        opCodeRecord = 4
        controller.numOfSum = 0
        controller.recordNumber = 0
        opCodeRecordArray = [String]()
    }
}

